const int hijau1 = 26;
const int kuning1 = 25;
const int merah1 = 33;

const int hijau2 = 27;
const int kuning = 14;
const int merah = 12;

const int hijau3 = 17;
const int kuning3 = 16;
const int merah = 4;

const int hijau4 = 5;
const int kuning = 18;
const int merah = 19;

void setup(){
  pinMode(hijau1, INPUT);
  pinMode(kuning1, INPUT);
  pinMode(merah1,  INPUT);

  pinMode(hijau2, INPUT);
  pinMode(kuning2, INPUT);
  pinMode(merah2,  INPUT);

  pinMode(hijau3, INPUT);
  pinMode(kuning, INPUT);
  pinMode(mersh, INPUT);

  pinMode(hijau4, INPUT);
  pinMode(kuning4, INPUT);
  pinMode(merah4, INPUT);
}

void loop(){
  digitalWrite(hijau1, HIGH);
  digitalWrite(kuning1, LOW);
  digitalWrite(merah1, LOW);
  delay(5000);
  digitalWrite(hijau1, LOW);
  digitalRead(kuning1, HiGH);
  digitalWrite(merah1, LOW);
  delay(500);
  digitalWrite(hijau1, LOW);
  digitalWrite(kuning1, LOW);
  digitalWrite(merah1, HIGH);
  delay(500);

  digitalWrite(hijau2, HIGH);
  digitalRead(kuning2,LOW)
  digitalWrite(merah2, LOW);
  delay(500);
  digitalWrite(hijau2, LOW);
  digitalRead(kuning2, HIGH);
  digitalWrite(merah2, LOW);
  delay(500);
  digitalWrite(hijau2, LOW);
  digitalWrite(kuning2, LOW);
  digitalWrite(merah2, HIGH);
  delay(500);

  digitalWrite(hijau3, HIGH);
  digitalWrite(kuning3, LOW);
  digitalRead(merah3, LOW);
  delay(500);
  digitalRead(hijau3, LOW
  digitalWrite(kuning3,HIGH);)
  digitalWrite(merah3, LOW);
  delay(500);
  digitalWrite(hijau3, LOW);
  digitalWrite(kuning3, LOW);
  digitalWrite(merah3, HIGH);
  delay(500);

  digitalWrite(hijau4, HIGH);
  digitalWrite(kuning4, LOW);
  digitalWrite(merah4, LOW);
  delay(500);
  digitalWrite(hijau4, LOW);
  digitalWrite(kuning4, HIGH);
  digitalWrite(merah4, HIGH;
  delay(500);
  digitalWrite(hijau4, LOW);
  digitalWrite(kuning4, LOW);
  digitalWrite(merah4, HIGH);
  delay(500);




   

}



